import React, {Component} from 'react';
import { Button,List } from 'antd-mobile';
import './App.css';

// import {createStore} from "redux";

class App extends Component {
    render() {
        const boss = 'liyunlong'
        return (<div>
            <h2>独立团{boss}</h2>
            <Yi y='zhangdamiao'/>
            <Yii yii='xxxxxx'/>
        </div>)
    }
}

// 使用class的方法来使用
class Yi extends Component {
    constructor(props) {
        super(props)
        this.state = {
            solders: ["sss", "ttt", "qqqq "]
        }
    }

    addsolder = () => {
        // console.log(`add solders`);
        this.setState({
            solders: [...this.state.solders, `xxx${Math.random() * 100}`]
        })
    }

    render() {
        // const boss = 'xxxx'
        return (
            <div>
                <h2>Yi.{this.props.y}</h2>
                <Button type="primary" onClick={this.addsolder}>新兵入伍</Button>
                <List renderHeader={()=>'士兵列表'}>
                    {this.state.solders.map((v, k) => {
                        return <List.Item key={k}>{v}</List.Item>
                    })}
                </List>
            </div>
        )
    }
}

// 使用 函数的方法来使用
function Yii(props) {
    return <h2>Yii.{props.yii}</h2>
}


export default App;
