import React from 'react'
import {Link, Route, Redirect} from "react-router-dom";
import App from './app'
import {connect} from "react-redux";
import {logout} from "./Auth.redux";
import {Button} from "antd-mobile";

function b() {
    return <h1>b</h1>
}

function c() {
    return <h1>c</h1>
}

@connect(state => state.auth, {logout})
class Dashboard extends React.Component {
    // constructor(props) {
    //     super(props)
    // }

    render() {
        // console.log(this.props.match.url);
        const match=this.props.match
        const redirectToLogin = <Redirect to="/login"></Redirect>
        const app = (
            <div>
                <h2>Dashboard</h2>
                {this.props.isAuth?<Button onClick={this.props.logout}> 注销</Button>:null}
                <ul>
                    <li><Link to={`${match.url}/`}>a</Link></li>
                    <li><Link to={`${match.url}/b`}>b</Link></li>
                    <li><Link to={`${match.url}/c`}>c</Link></li>
                </ul>
                <Route path={`${match.url}/`} exact component={App}></Route>
                <Route path={`${match.url}/b`} component={b}></Route>
                <Route path={`${match.url}/c`} component={c}></Route>
            </div>);
        return this.props.isAuth ? app : redirectToLogin
    }
}

export default Dashboard;
