/*把所有的reducer进行合并*/
import {combineReducers} from "redux";
import {auth} from "./Auth.redux";
import {counter} from "./index.redux";

export default combineReducers({auth,counter})
