import React from 'react'
import {connect} from 'react-redux'
import {add, remove, addAsync} from './index.redux'
// const mapStateToProps = (state) => {
//     return {num: state}
// }
// const actionCreators = {add, remove, addAsync}
// App = connect(mapStateToProps, actionCreators)(App)

/*
* @connect 里面的参数
* 你要state什么属性放到props里
* 你要什么方法放到props里，自动dispatch
* */
@connect(state=>({num:state.counter}), {add, remove, addAsync})
class App extends React.Component {
    render() {
        const num = this.props.num
        const add = this.props.add
        const remove = this.props.remove
        const addAsync = this.props.addAsync
        return (
            <div>
                <h1>
                    xxxx{num}xxxx
                </h1>
                <button onClick={add}>[+]</button>
                <button onClick={remove}>[-]</button>
                <button onClick={addAsync}>[0]</button>
            </div>)
    }
}


export default App;
