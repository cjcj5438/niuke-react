/*验证相关*/
import React from 'react'
import {connect} from "react-redux";
import {login,getUserDate} from "./Auth.redux";
import {Redirect} from "react-router-dom";
import {Button} from "antd-mobile";

// 这里又连个reducers 每一个reducer 都有一个state 。这个时候yong combineReducers 合并
@connect(state=>state.auth,{login,getUserDate})
class Auth extends React.Component{
    constructor(props){
        super(props)
        this.state={
            data:{}
        }
    }
    componentDidMount() {
        this.props.getUserDate()
    }

    render() {
        return (<div>
            <h2>我的名字是{this.props.user},年龄{this.props.age}</h2>
            {this.props.isAuth?<Redirect to="/dashboard"></Redirect>:null}
            <h2>你没有权限需要登录</h2>
            <Button onClick={this.props.login}>login</Button>
        </div>)
    }
}
export default Auth;
