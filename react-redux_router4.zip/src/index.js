import React from 'react'
import ReactDom from 'react-dom'

import Auth from './Auth'
import Dashboard from './Dashboard'
import {createStore, applyMiddleware, compose} from 'redux'
import thunk from 'redux-thunk'
import {Provider} from 'react-redux'
// import {counter} from "./index.redux";
import reducers from './reducer'
import './config'
import {BrowserRouter,Route,Redirect,Switch} from 'react-router-dom'
const reduxDevtools = window.devToolsExtension ? window.devToolsExtension() : () => {}
const store = createStore(reducers, compose(applyMiddleware(thunk), reduxDevtools))


/*
* 登录
*   没有登录信息 统一跳转login
* 页面 导航 显示 注销
* a页面
* b页面
* c页面
* */


ReactDom.render(
    <Provider  store={store}>
        <BrowserRouter>
            <div>
                <Switch>
                    {/*只命中渲染第一个route*/}
                    {/*exact 路由嵌套的时候这个不要用*/}
                    <Route path='/login' exact component={Auth}></Route>
                    <Route  path='/dashboard' component={Dashboard}></Route>
                    <Redirect to='/dashboard'></Redirect>
                </Switch>
                <hr/>
                {/*<App/>*/}
            </div>
        </BrowserRouter>
    </Provider>,
    document.getElementById('root'))

// import {createStore} from "redux";
//
//
//
// // 新建store
// const store = createStore(counter)
// const init = store.getState();
// console.log(init);
//
// // 代码冗长
// function Linkstener() {
//     const current=store.getState()
//     console.log(`现在是几`,current)
// }
// store.subscribe(Linkstener)
//
// // 派发事件
// store.dispatch({type:'aaa'})
// store.dispatch({type:'aaa'})
//
//
// console.log(store.getState());

// class Test extends React.Component{
//     render() {
//         console.log(this.props)
//         // this.props.history.push('/')
//         return <h2>测试组件{this.props.match.params.id}</h2>
//     }
// }
