const AAA='AAA';
const BBB='BBB';

// reducer建立 根据老的state 和 action 生成state
export function counter(state = 0, action) {
    switch (action.type) {
        case 'AAA':
            return state + 1;
        case 'BBB':
            return state - 1;
        default:
            return 10;
    }
}

// action creator
export function add() {
    return {type:AAA}
}
export function remove() {
    return {type:BBB }
}
export function addAsync() {
    return dispatch=>{
        setTimeout(()=>{
              dispatch(add())
        },2000)
    }
}
