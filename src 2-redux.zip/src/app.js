import React from 'react'

class App extends React.Component{
    render(){
        const store = this.props.store
        const num=store.getState()
        const add=this.props.add
        const remove=this.props.remove
        const addAsync=this.props.addAsync
        return(
            <div>
                <h1>
                    xxxx{num}xxxx
                </h1>
                <button onClick={()=>{store.dispatch(add())}}>[+]</button>
                <button onClick={()=>{store.dispatch(remove())}}>[-]</button>
                <button onClick={()=>{store.dispatch(addAsync())}}>[0]</button>
            </div>)
    }
}

export default App;
