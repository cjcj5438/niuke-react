import React from 'react'
import ReactDom from 'react-dom'
import App from './app'
import {createStore,applyMiddleware,compose} from 'redux'
import thunk from 'redux-thunk'
import {counter,add,remove,addAsync} from "./index.redux";

const reduxDevtools=window.devToolsExtension?window.devToolsExtension():()=>{}
const store =createStore(counter,compose(applyMiddleware(thunk),reduxDevtools))
function render(){
    ReactDom.render(<App sto re={store} add={add} remove={remove} addAsync={addAsync}/>, document.getElementById('root'))
}
render();
store.subscribe(render)
// import {createStore} from "redux";
//
//
//
// // 新建store
// const store = createStore(counter)
// const init = store.getState();
// console.log(init);
//
// // 代码冗长
// function listener() {
//     const current=store.getState()
//     console.log(`现在是几`,current)
// }
// store.subscribe(listener)
//
// // 派发事件
// store.dispatch({type:'aaa'})
// store.dispatch({type:'aaa'})
//
//
